const c = "pf2e-mobile";
console.log("init module2");
const m = {
  default: "default",
  sheet: "sheet"
};
Hooks.once("init", () => {
  console.debug("pf2e mobile startss"), sessionStorage.removeItem(`${c}_sidebar_state`);
});
Hooks.on("renderCharacterSheetPF2e", async (a, o, r) => {
  console.debug({ _app: a, _data: r });
  const e = o.get(0);
  if (!e)
    throw new Error("Could not get character sheet render even html.");
  const d = sessionStorage.getItem(
    `${c}_sidebar_state`
  ), s = document.createElement("a");
  s.setAttribute("data-tab", "sidebar"), s.role = "tab", s.classList.add("item"), d === "sheet" && (e.querySelectorAll(".sheet-navigation > .item").forEach((t) => {
    t.classList.remove("active");
  }), s.classList.add("active"));
  const l = document.createElement("i");
  l.classList.add("fa-solid", "fa-bars"), s.appendChild(l);
  const b = e?.querySelector(".sheet-navigation");
  b?.insertBefore(s, b.childNodes[2]);
  const n = document.createElement("section");
  if (n.classList.add("tab", "sidebar-section", "major"), n.setAttribute("data-group", "primary"), n.setAttribute("data-tab", "sidebar"), e.querySelector(".sheet-content")?.appendChild(n), new MutationObserver((t) => {
    t.forEach((i) => {
      i.attributeName === "class" && (i.target.classList.contains("active") ? (console.debug("moving sidebar to sheet section"), u(e)) : h(e));
    });
  }).observe(s, {
    attributes: !0,
    childList: !1,
    subtree: !1
  }), d === "sheet" && (u(e), e.querySelectorAll(".sheet-content > .tab").forEach((t) => t.classList.remove("active")), e.querySelector(".sidebar-section")?.classList.add("active")), d === "sheet") {
    const t = e.querySelector(
      '.sheet-navigation > a[data-tab="character"]'
    ), i = (f) => {
      console.debug("clicking character button"), document.querySelector('.sheet-navigation > a[data-tab="sidebar"]')?.classList.remove("active"), document.querySelector('.sheet-content > section[data-tab="sidebar"]')?.classList.remove("active"), t.classList.add("active"), e.querySelector('.sheet-content > [data-tab="character"]')?.classList.add("active"), t.removeEventListener("click", i);
    };
    t?.addEventListener("click", i);
  }
});
function u(a) {
  const r = document.querySelector(".window-content > form")?.querySelector("aside");
  if (!r) {
    console.error("Error parsing DOM! Mobile mode will not function properly.");
    return;
  }
  a.querySelector(".sidebar-section")?.appendChild(r), sessionStorage.setItem(`${c}_sidebar_state`, m.sheet);
}
function h(a) {
  const o = a.querySelector(
    '.sheet-content > section[data-tab="sidebar"] aside'
  );
  if (!o)
    throw new Error("Could not remove aside from section content.");
  a.querySelector('.sheet-content > section[data-tab="sidebar"]')?.removeChild(o), document.querySelector(".window-content > form")?.appendChild(o), sessionStorage.setItem(
    `${c}_sidebar_state`,
    m.default
  );
}
